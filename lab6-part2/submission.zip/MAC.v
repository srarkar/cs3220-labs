module mac #(
    parameter IN_WIDTH = 8,
    parameter IN_FRAC = 0,
    parameter OUT_WIDTH = 8,
    parameter OUT_FRAC = 0,
    parameter MULT_LAT = 3,
    parameter ADD_LAT = 1,
    parameter K = 1,
    parameter ROWS = 1,
    parameter COLS = 1,
    parameter COLS_IDX = 1,
    parameter ROWS_IDX = 1
)(
    input                      clk,
    input                      rst,
    input                      rst_accumulator_in,
    input                      stream_out_rdy_in,
    input       [IN_WIDTH-1:0] row_data_in,
    input       [IN_WIDTH-1:0] col_data_in,
    input       [IN_WIDTH-1:0] bypass_data_in, 

    output reg  [IN_WIDTH-1:0] row_data_out,
    output reg  [IN_WIDTH-1:0] col_data_out,
    output reg                 rst_accumulator_out,
    output reg                 stream_out_rdy_out,
    output reg [OUT_WIDTH-1:0] psum_out,

    output     [OUT_WIDTH-1:0] psum_capture_out
);
    localparam COLS_WIDTH = $clog2(COLS);
    wire [OUT_WIDTH-1:0]    multiplier_out;
    wire                    multiplier_done;
    wire [IN_WIDTH-1:0]     adder_in_A;
    wire [IN_WIDTH-1:0]     adder_in_B;
    wire [OUT_WIDTH-1:0]    adder_out;
    wire                    adder_done;
    
    reg [OUT_WIDTH-1:0] psum [0:(1 << COLS_WIDTH)-1];
    reg [OUT_WIDTH-1:0] mult_out;

    wire bypass_en;
    wire [31:0] temp = COLS - 1;
    wire [$clog2(COLS)-1:0] bypass_counter_max = temp[$clog2(COLS)-1:0];
    reg  [$clog2(COLS)-1:0] bypass_counter;

    wire [IN_WIDTH-1:0] mul_in_A = row_data_in;
    wire [IN_WIDTH-1:0] mul_in_B = col_data_in;
    multiplier #(
        .INPUT_A_WIDTH(IN_WIDTH),
        .INPUT_B_WIDTH(IN_WIDTH),
        .INPUT_A_FRAC(IN_FRAC),
        .INPUT_B_FRAC(IN_FRAC),
        .OUTPUT_WIDTH(OUT_WIDTH),
        .OUTPUT_FRAC(OUT_FRAC),
        .DELAY(MULT_LAT)
    ) mul (
        .clk(clk),
        .reset(rst),
        .stall(0),
        .en(~rst),
        .a_in(mul_in_A),
        .b_in(mul_in_B),
        .out(multiplier_out),
        .done(multiplier_done)
    );

    // Fix-point adder
    assign adder_in_A = mult_out;
    assign adder_in_B = (rst_accumulator_in ? '0 : adder_out);

    adder #(
        .INPUT_A_WIDTH(IN_WIDTH),
        .INPUT_B_WIDTH(IN_WIDTH),
        .INPUT_A_FRAC(IN_FRAC),
        .INPUT_B_FRAC(IN_FRAC),
        .OUTPUT_WIDTH(OUT_WIDTH),
        .OUTPUT_FRAC(OUT_FRAC),
        .DELAY(ADD_LAT)
    ) add(
        .clk(clk),
        .reset(rst),
        .stall(0),
        .en(~rst && multiplier_done),
        .a_in(adder_in_A),
        .b_in(adder_in_B),
        .out(adder_out),
        .done(adder_done)
    );

    //pass the row/col/rst/stream_out data 1 clock cycle later
    always @(posedge clk) begin
        if (rst) begin
            row_data_out        <= 0;
            col_data_out        <= 0;
            rst_accumulator_out <= 0;
            stream_out_rdy_out  <= 0;
        end
        else begin
            row_data_out        <= row_data_in;
            col_data_out        <= col_data_in;
            rst_accumulator_out <= rst_accumulator_in;
            stream_out_rdy_out  <= stream_out_rdy_in;
        end
    end

    //mult 1 clock cycle later
    always @(posedge clk) begin
        if (rst) begin
            mult_out <= 0;
        end 
        else if (multiplier_done) begin
            mult_out <= multiplier_out;
        end 
        else begin
            mult_out <= 0;
        end
    end

    //accumulate 1 clock cycle later
    always @(posedge clk) begin
        if (rst) begin
            psum[0] <= 0;
        end
        else begin
            psum[0] <= adder_out;
        end
    end

    // propagate the psum shift register (delay = K = COLS - col_idx - 1)
    generate
        genvar i;
        for (i = 0; i < (1 << COLS_WIDTH) - 1; i = i + 1) begin: psum_propagate
            always @(posedge clk) begin
                if (rst) begin
                    psum[i+1] <= 0;
                end
                else begin
                    psum[i+1] <= psum[i];
                end
            end
        end
    endgenerate

    reg stream_started;
    always @(posedge clk) begin
        if (rst) begin
            stream_started <= 0;
        end
        else if (stream_out_rdy_in) begin
            stream_started <= 1;
        end
    end

    assign bypass_en = (bypass_counter != 0);

    reg stream_out_rdy_in_reg;
    always @(posedge clk) begin
        if (rst) begin
            stream_out_rdy_in_reg <= 0;
        end else begin
            stream_out_rdy_in_reg <= stream_out_rdy_in;
        end
    end

    always @(posedge clk) begin
        if (rst) begin
            bypass_counter <= '0;
        end else if (bypass_counter == bypass_counter_max) begin
            bypass_counter <= '0;
        end else if (stream_out_rdy_in_reg || bypass_en) begin
            bypass_counter <= bypass_counter + 1;
        end else begin
            bypass_counter <= '0;
        end
    end

    reg [OUT_WIDTH-1:0] psum_reg;
    always @(posedge clk) begin
        if (rst) begin
            psum_reg <= 0;
        end else begin
            psum_reg <= psum[K];
        end
    end

    assign psum_capture_out = psum_reg;

    //output the psum via bypass chain (used for legacy downstream connectivity)
    always @(posedge clk) begin
        if (rst) begin
            psum_out     <= '0;
        end
        else if (!bypass_en && stream_started) begin
            psum_out     <= psum_reg;
        end
        else if (bypass_en) begin
            psum_out     <= bypass_data_in;
        end else begin
            psum_out     <= '0;
        end
    end

endmodule